n_hosts=4
for i in range(0,int(n_hosts/2)):
    for j in range(n_hosts):
        f = open("h%d%d-sender.sh"%(i+1,j+1), "w")
        f.write('timetorun=4\n')
        f.write('stoptime=$((timetorun + $(date +%s))) \n')
        f.write('while [ $(date +%s) -lt $stoptime ]; do  \n')
        f.write('   ./fcttest -c -a 10.0.%d.%d -p 5000 -g 4608  \n'%(i+1+int(n_hosts/2),j+1))
        #f.write('   iperf3 -c 10.0.%d.%d -n 4500 \n'%(i+1+int(n_hosts/2),j+1))
        #f.write('   iperf3 -c 10.0.%d.%d -t 4  \n'%(i+1+int(n_hosts/2),j+1))
        f.write('done  \n')
        f.close()
    


 
 

    
 
