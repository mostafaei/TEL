timetorun=4
stoptime=$((timetorun + $(date +%s))) 
while [ $(date +%s) -lt $stoptime ]; do  
   ./fcttest -c -a 10.0.4.2 -p 5000 -g 4608  
done  
