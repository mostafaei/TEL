#!/usr/bin/python

# Copyright 2013-present Barefoot Networks, Inc. 
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from mininet.net import Mininet
from mininet.topo import Topo
from mininet.log import setLogLevel, info
from mininet.cli import CLI
from mininet.link import TCLink

from p4_mininet import P4Switch, P4Host

import argparse
from time import sleep
import os, time, re
import subprocess
import networkx as nx

_THIS_DIR = os.path.dirname(os.path.realpath(__file__))
_THRIFT_BASE_PORT = 9090

parser = argparse.ArgumentParser(description='Mininet demo')
parser.add_argument('--behavioral_exe', help='Path to behavioral executable',
                    type=str, action="store", required=False)
#parser.add_argument('--log-file', help='Path to log file',
#                    type=str, action="store", required=True)
parser.add_argument('--json', help='Path to JSON config file',
                    type=str, action="store", required=False)
parser.add_argument('--cli', help='Path to BM CLI',
                    type=str, action="store", required=False)
parser.add_argument('--size', help='UDP packet size',
                    type=str, action="store", required=False)

args = parser.parse_args()

G = nx.Graph()
args.json="TEL-DC.json"
args.cli="simple_switch_CLI"
args.behavioral_exe="simple_switch"

class MyTopo(Topo):
    def __init__(self, sw_path, json_path, nb_hosts, nb_spines, nb_leaves, links, **opts):
        # Initialize topology and default options
        print('opts',opts)
        Topo.__init__(self, **opts)

        for i in xrange(nb_spines):
            #G.add_node('s%d' % (i + 1))
            switch = self.addSwitch('s%d' % (i + 1),
                                    sw_path = sw_path,
                                    json_path = "TEL-DC-spine.json",
                                    thrift_port = _THRIFT_BASE_PORT + i,
                                    log_console = False,
                                    pcap_dump = False,
                                    device_id = i)
        for i in xrange(nb_leaves):
            #G.add_node('l%d' % (i + 1))
            switch = self.addSwitch('l%d' % (i + 1),
                                    sw_path = sw_path,
                                    json_path = "TEL-DC-leaf.json",
                                    thrift_port = _THRIFT_BASE_PORT + i+nb_leaves,
                                    log_console = False,
                                    pcap_dump = False,
                                    device_id = i+nb_leaves)

        
        for i in range(nb_spines):
    		for j in range(nb_leaves):
        		host_ip = "10.0.%d.%d/24" % (i+1, j+1)
        		#print('h%d%d: ' % (i+1, j+1),host_ip)
        		host_mac = '00:00:00:00:%02x:%02x' % (i+1, j+1)
        		host = self.addHost('h%d%d' % (i + 1,j+1),ip=host_ip,mac=host_mac)
        
        for a, b in links:
            #delay_key = ''.join([host_name, sw])
            #delay = latencies[delay_key] if delay_key in latencies else '0ms'
            #bw = bws[delay_key] if delay_key in bws else None
            #print('------------link----------------',a,b)
            self.addLink(a, b, bw=100)
            #G.add_edge(a,b)
        

def read_topo():
    nb_hosts = 0
    nb_spines = 0
    nb_leaves = 0
    links = []
    with open("topo.txt", "r") as f:
        line = f.readline()[:-1]
        w, nb_spines = line.split()
        assert(w == "spines")
        line = f.readline()[:-1]
        w, nb_leaves = line.split()
        assert(w == "leaves")
        line = f.readline()[:-1]
        w, nb_hosts = line.split()
        assert(w == "hosts")
        for line in f:
            if not f: break
            a, b = line.split()
            #print('link:',(a, b))
            links.append( (a, b) )
    return int(nb_hosts), int(nb_spines), int(nb_leaves), links
    

def main(b,t,l,Run):
    nb_hosts, nb_spines,nb_leaves, links = read_topo()

    topo = MyTopo(args.behavioral_exe,
                  args.json,
                  nb_hosts, nb_spines, nb_leaves, links)

    net = Mininet(topo = topo,
                  host = P4Host,
                  switch = P4Switch,
                  link = TCLink,
                  controller = None )
    net.start()

    for host_name in topo.hosts():
            h = net.get(host_name)
            #print('Host; ',h)
            h_iface = h.intfs.values()[0]
            link = h_iface.link

            sw_iface = link.intf1 if link.intf1 != h_iface else link.intf2
            # phony IP to lie to the host about
            host_id = int(host_name[1:])
            sw_ip = '10.0.%d.254' % host_id

            # Ensure each host's interface name is unique, or else
            # mininet cannot shutdown gracefully
            h.defaultIntf().rename('%s-eth0' % host_name)
            # static arp entries and default routes
            h.cmd('arp -i %s -s %s %s' % (h_iface.name, sw_ip, sw_iface.mac))
            h.cmd('ethtool --offload %s rx off tx off' % h_iface.name)
            h.cmd('ip route add %s dev %s' % (sw_ip, h_iface.name))
            h.cmd("sysctl -w net.ipv6.conf.all.disable_ipv6=1")
            h.cmd("sysctl -w net.ipv6.conf.default.disable_ipv6=1")
            h.cmd("sysctl -w net.ipv6.conf.lo.disable_ipv6=1")
            h.cmd("sysctl -w net.ipv4.tcp_congestion_control=reno")
            h.cmd("iptables -I OUTPUT -p icmp --icmp-type destination-unreachable -j DROP")

            h.setDefaultRoute("via %s" % sw_ip)

    sleep(1)

    for i in xrange(nb_spines):
        s = net.get('s%d' % (i + 1))
        print "##################################\n"
        print "Switch (s%d)" % (i + 1)
        result = s.cmd('ifconfig')
        #print	result
        print "MAC Address: \t%s" 	% s.MAC()
        print "IP Address: \t%s\n" 	% s.IP()
        print "##################################"
        cmd = [args.cli, "--json", "TEL-DC-spine.json",
               "--thrift-port", str(_THRIFT_BASE_PORT + i)]
        with open("s%d-commands.txt"%(i + 1), "r") as f:
            print " ".join(cmd)
            try:
                output = subprocess.check_output(cmd, stdin = f)
                print output
            except subprocess.CalledProcessError as e:
                print e
                print e.output
    for i in xrange(nb_leaves):
        s = net.get('l%d' % (i + 1))
        print "##################################\n"
        print "Switch (l%d)" % (i + 1)
        result = s.cmd('ifconfig')
        #print	result
        print "MAC Address: \t%s" 	% s.MAC()
        print "IP Address: \t%s\n" 	% s.IP()
        print "##################################"
        cmd = [args.cli, "--json", "TEL-DC-leaf.json",
               "--thrift-port", str(_THRIFT_BASE_PORT + i+nb_leaves)]
        with open("l%d-commands.txt"%(i + 1), "r") as f:
            print " ".join(cmd)
            try:
                output = subprocess.check_output(cmd, stdin = f)
                print output
            except subprocess.CalledProcessError as e:
                print e
                print e.output

    sleep(1)

    print "Ready !"
    
    ## do test for link failure
    print("********************** Link faliure test *********************")
    print( "Testing bandwidth between clients and server\n" )
    #G = nx.read_graphml('AttMpls.graphml')
    #nx.draw(G, with_labels=True)
    hostList=[]
    processList=[]
    n_hosts=4

    
    s1,l1,l3,l4=net.getNodeByName('s1','l1','l3','l4')
    #'''
    for i in range(int(n_hosts/2),n_hosts):
        for j in range(n_hosts):
        	h=net.getNodeByName('h%d%d'%(i+1,j+1))
        	hostList.append(h)
        	#h.popen(' ./fcttest -s -p 5000 -g 4608', shell=True)
                h.popen(' TrafficGenerator/bin/server -p 5001 -d', shell=True)
        	#h.popen(' iperf3 -s ', shell=True)
    
    #print(hostList)
    for i in range(0,int(n_hosts/2)):
        for j in range(n_hosts):
            h=net.getNodeByName('h%d%d'%(i+1,j+1))
            p=h.popen(' TrafficGenerator/bin/client -b %d -c TrafficGenerator/conf/cfg-DC-%s.txt -n 500 -l flows%d%d.txt -s 123 -r TrafficGenerator/bin/result.py > results/h%d%d-%s-L%d-Run%d-F0.txt'%(b,t,i+1,j+1,i+1,j+1,t,l,Run), shell=True)
            #p=h.popen(' bash h%d%d-sender.sh > h%d%d-Iperf3-F1.txt'%(i+1,j+1,i+1,j+1), shell=True)
            processList.append(p)

    #'''
    
    #print('--------------waiting------------------')
    #sleep(.500)
    #l1.cmd("echo register_write ports_status_r 0 7 | simple_switch_CLI --thrift-port 9094 &")
    #l1.cmd("echo register_write failed_port 0 1 | simple_switch_CLI --thrift-port 9094 &")
    #s1.cmd("echo register_write ports_status_r 0 7 | simple_switch_CLI --thrift-port 9090 &")
    #s1.cmd("echo register_write failed_port 0 1 | simple_switch_CLI --thrift-port 9090 &")
    #l3.cmd("echo 'table_modify MyIngress.ecmp_group_to_nhop set_nhop 0 => 00:00:00:03:01:00 6' | simple_switch_CLI --thrift-port 9096 &")

    
    for pp in processList:
        pp.wait()
    os.system('pkill -f iperf3')
    os.system("pkill -f 'TrafficGenerator/bin/server -p 5001 -d'")
 
  
    #CLI( net )
    net.stop()

if __name__ == '__main__':
    setLogLevel( 'info' )
    #Traffic=['WebSearch','DataMining']
    Traffic=['WebSearch']
    for t in Traffic:
        for r in range(1,11):
            for b in range(20,80,10):
                main(b,t,b,r)
