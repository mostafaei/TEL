   iperf3 -c 10.0.4.4 -t 4
