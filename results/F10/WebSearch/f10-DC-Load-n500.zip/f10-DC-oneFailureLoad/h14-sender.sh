   iperf3 -c 10.0.3.4 -t 4
